Strict joint iteration: reproduction

Requirements
Python 3.14 and Python 3.12 on a POSIX system, and Node.js 24 (TypeScript type stripping). Only the Python standard library is used.

Command
python3.14 -B reproduce.py --python312 /path/to/python3.12 --node /path/to/node

The first stage, code/prepare_reference.py, downloads the TC39 proposal reference implementation at a fixed commit over HTTPS (with curl as a fallback when Python has no usable certificate store) and builds the object-validation and eager-probe variants from it. Without network access, pass a local copy of that file with --reference /path/to/original.ts. The remaining stages run the native zip and map consumers under Python 3.14 and 3.12, execute the three reference variants in Node, self-test the specification oracle and compare everything in code/verify.py. All stages run in runs/<UTC timestamp>/ with an 18-second CPU limit per process (--cpu-limit 120 for slow machines).

The summaries are compared with expected.json, ignoring runtime versions and timings. The command prints PASS and writes CHECK.json when they agree.

Expected counts
28,086 native cases; 25,105 protocol cases per variant; 6,628 differences for the unmodified reference; no differences for the object-validation variant; 792 trace differences for the eager-probe variant, 396 of them with a changed exposed error.

Third-party source
SOURCE.txt describes the rights of the downloaded reference file; the license of this package does not cover it.

Files
RESULTS.tsv lists the program, line and output path of each table. ENVIRONMENT.json describes the reference run.
