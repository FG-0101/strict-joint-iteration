"""Native Python consumers and an independent closed-form finite source oracle."""
from pathlib import Path
import argparse,gzip,itertools,json,sys,time
class SourceFault(Exception):pass
class Source:
 def __init__(self,i,length,terminal,trace):self.i=i;self.length=length;self.terminal=terminal;self.pos=0;self.trace=trace
 def __iter__(self):return self
 def __next__(self):
  self.trace.append(['next',self.i])
  if self.pos<self.length:
   value=[self.i,self.pos];self.pos+=1;self.trace.append(['value',self.i,value[1]]);return value
  if self.terminal=='N':self.trace.append(['raise',self.i]);raise SourceFault('next:'+str(self.i))
  self.trace.append(['done',self.i]);raise StopIteration
 def close(self):self.trace.append(['close',self.i])
def native(scripts,mode,kind):
 trace=[];sources=[Source(i,*s,trace) for i,s in enumerate(scripts)];rows=[];error=None;completed=False
 try:
  joint=zip(*sources,strict=mode=='strict') if kind=='zip' else map(lambda *xs:xs,*sources,strict=mode=='strict')
  while True:
   trace.append(['client-next',len(rows)])
   try:row=next(joint)
   except StopIteration:completed=True;break
   rows.append(list(row))
 except SourceFault as e:error=str(e)
 except ValueError:error='Mismatch'
 except TypeError:error='TypeError'
 return {'rows':rows,'trace':trace,'error':error,'completed':completed,'positions':[s.pos for s in sources]}
def expected(scripts,mode,kind):
 n=len(scripts);rows=[];trace=[];pos=[0]*n
 if n==0:
  if kind=='map':return dict(rows=[],trace=[],error='TypeError',completed=False,positions=[])
  return dict(rows=[],trace=[['client-next',0]],error=None,completed=True,positions=[])
 m=min(s[0] for s in scripts)
 for j in range(m):
  trace.append(['client-next',j]);rows.append([[i,j] for i in range(n)])
  for i in range(n):trace.extend([['next',i],['value',i,j]]);pos[i]+=1
 trace.append(['client-next',m]);first=next(i for i,s in enumerate(scripts) if s[0]==m)
 def observation(i):
  trace.append(['next',i]);length,end=scripts[i]
  if length>m:trace.append(['value',i,m]);pos[i]+=1;return 'V'
  trace.append(['raise' if end=='N' else 'done',i]);return end
 for i in range(first):assert observation(i)=='V'
 token=observation(first);error=None
 if token=='N':error='next:'+str(first)
 elif mode=='strict':
  if first>0:error='Mismatch'
  else:
   for i in range(1,n):
    token=observation(i)
    if token!='D':error='next:'+str(i) if token=='N' else 'Mismatch';break
 return dict(rows=rows,trace=trace,error=error,completed=error is None,positions=pos)
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);start=time.monotonic();count=0;fail=[];counts={};variants=['zip','map'] if sys.version_info>=(3,14) else ['zip'];scripts=list(itertools.product(range(4),['D','N']))
 with gzip.open(a.output/'rows.jsonl.gz','wt',encoding='utf-8') as out:
  for n in range(5):
   for vector in itertools.product(scripts,repeat=n):
    for mode in ['shortest','strict']:
     for kind in variants:
      case={'n':n,'scripts':vector,'mode':mode,'kind':kind};actual=native(vector,mode,kind);want=expected(vector,mode,kind);count+=1
      if actual!=want:fail.append({'case':case,'actual':actual,'expected':want})
      key=kind+'|'+mode;group=counts.setdefault(key,{'cases':0,'normal_done':0,'mismatch':0,'source_error':0,'type_error':0,'unemitted_values':0,'close_events':0});group['cases']+=1;group['normal_done']+=actual['completed'];e=actual['error'];group['mismatch']+=e=='Mismatch';group['source_error']+=isinstance(e,str) and e.startswith('next:');group['type_error']+=e=='TypeError';group['unemitted_values']+=sum(actual['positions'])-n*len(actual['rows']);group['close_events']+=sum(t[0]=='close' for t in actual['trace']);out.write(json.dumps({'case':case,'actual':actual},sort_keys=True,separators=(',',':'))+'\n')
 summary={'python':sys.version,'source_vectors':sum(8**n for n in range(5)),'cases':count,'counts':counts,'oracle_mismatches':len(fail),'seconds':time.monotonic()-start};(a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(a.output/'failures.json').write_text(json.dumps(fail,indent=2)+'\n');print(json.dumps(summary));assert not fail
if __name__=='__main__':main()
