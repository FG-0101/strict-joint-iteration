// Execute the fixed third-party reference implementation without modifying its source.
import fs from 'node:fs';
import zlib from 'node:zlib';
import {pathToFileURL} from 'node:url';
const [output,reference]=process.argv.slice(2);if(!output||fs.existsSync(output))throw Error('a new output path is required');fs.mkdirSync(output,{recursive:true});
const nativeAvailability={zip:typeof Iterator.zip,zipKeyed:typeof Iterator.zipKeyed};
await import(pathToFileURL(reference));
function* vectors(items,n,prefix=[]){if(n===0){yield prefix;return}for(const x of items)yield* vectors(items,n-1,[...prefix,x])}
function* cases(){let id=0;
 for(const n of [2,3])for(const prefix of [0,1])for(const tokens of vectors(['D','V','N','G','X','P'],n))for(const closes of vectors(['R','E','P'],n))for(const mode of ['shortest','strict'])yield {id:id++,family:'protocol',n,prefix,tokens,closes,mode};
 for(const n of [1,2,3,4])for(const closes of vectors(['R','E','P'],n))for(const mode of ['shortest','strict'])for(const consumer_return of ['before-first','after-one-row'])yield{id:id++,family:'return',n,prefix:1,tokens:Array(n).fill('V'),closes,mode,consumer_return};
 yield {id:id++,family:'zero',n:0,prefix:0,tokens:[],closes:[],mode:'strict'};
}
function evaluate(c){const trace=[],rows=[];let error=null,completed=false;
 const sources=c.tokens.map((token,i)=>{let count=0;return {[Symbol.iterator](){return this},next(){trace.push(['next',i]);const call=count++,t=call<c.prefix?'V':call===c.prefix?token:'D';if(t==='N')throw Error('next:'+i);if(t==='P')return 7;return {get done(){trace.push(['done',i]);if(t==='G')throw Error('done:'+i);return t==='D'},get value(){trace.push(['value',i]);if(t==='X')throw Error('value:'+i);return [i,call]}}},get return(){trace.push(['get-return',i]);return function(){trace.push(['return',i]);if(c.closes[i]==='E')throw Error('close:'+i);return c.closes[i]==='P'?0:{done:true}}}}});
 try {const joint=Iterator.zip(sources,{mode:c.mode});
  if(c.consumer_return){if(c.consumer_return==='after-one-row'){trace.push(['client-next',0]);const row=joint.next();if(row.done)throw Error('fixture failed');rows.push(row.value)}trace.push(['client-return']);const ret=joint.return();completed=ret.done;}
  else {for(let round=0;round<c.prefix+4;round++){trace.push(['client-next',round]);const row=joint.next();if(row.done){completed=true;break}rows.push(row.value)}if(!completed)throw Error('finite fixture did not end');}
 } catch(e){error=e instanceof TypeError?'TypeError':e.message;}
 return{rows,trace,error,completed};
}
let lines=[],count=0,groups={};const begin=performance.now();
for(const c of cases()){const actual=evaluate(c);count++;const key=c.family+'|'+c.mode;const g=groups[key]??={cases:0,normal_done:0,type_error:0,source_error:0,close_error:0};g.cases++;g.normal_done+=actual.completed;g.type_error+=actual.error==='TypeError';g.source_error+=typeof actual.error==='string'&&/^(next|done|value):/.test(actual.error);g.close_error+=typeof actual.error==='string'&&actual.error.startsWith('close:');lines.push(JSON.stringify({case:c,actual},(key,value)=>value===undefined?'@undefined':value));}
fs.writeFileSync(output+'/rows.jsonl.gz',zlib.gzipSync(lines.join('\n')+'\n'));
const summary={node:process.version,v8:process.versions.v8,nativeAvailability,cases:count,groups,seconds:(performance.now()-begin)/1000};fs.writeFileSync(output+'/summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));
