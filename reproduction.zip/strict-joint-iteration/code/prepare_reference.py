"""Acquire the fixed reference and construct the two experimental interventions."""
from pathlib import Path
import argparse,shutil,urllib.request,urllib.error,subprocess
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--source',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
url='https://raw.githubusercontent.com/tc39/proposal-joint-iteration/31dbb7a7e12bc1e7ba94f8994eb28ae34e29bb2d/src/index.ts'
original=a.output/'original.ts'
if a.source:shutil.copy2(a.source,original)
else:
 try:
  with urllib.request.urlopen(url,timeout=30) as response:original.write_bytes(response.read())
 except urllib.error.URLError:
  curl=shutil.which('curl')
  if not curl:raise
  subprocess.run([curl,'--fail','--location','--proto','=https','--proto-redir','=https','--max-time','30','--output',str(original),url],check=True)
s=original.read_text()
replacements=[('let iterResult = iter.next.call(iter.iter);',"let iterResult = iter.next.call(iter.iter);\n          if (!isObject(iterResult)) throw new TypeError('iterator result must be an object');"),('let { done } = (toCheck as IteratorRecord).next.call((toCheck as IteratorRecord).iter);',"let probeResult = (toCheck as IteratorRecord).next.call((toCheck as IteratorRecord).iter);\n                if (!isObject(probeResult)) throw new TypeError('iterator result must be an object');\n                let { done } = probeResult;"),('iterK!.iter.return?.();',"let returnMethod = iterK!.iter.return;\n        if (returnMethod != null) {\n          if (typeof returnMethod !== 'function') throw new TypeError('return must be callable');\n          let returnResult = returnMethod.call(iterK!.iter);\n          if (!isObject(returnResult)) throw new TypeError('return result must be an object');\n        }")]
for old,new in replacements:assert s.count(old)==1,old;s=s.replace(old,new)
(a.output/'object_validation.ts').write_text(s)
needle='let { done } = probeResult;';assert s.count(needle)==1;eager=s.replace(needle,needle+'\n                if (!done) void probeResult.value;')
(a.output/'eager_probe.ts').write_text(eager)
print('Fixed source and both interventions ready')
