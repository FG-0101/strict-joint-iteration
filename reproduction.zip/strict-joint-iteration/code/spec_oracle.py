"""Finite oracle for IteratorZip and the iterator abstract operations.

Derived from ECMA-262 clauses 27.1.3.4.1, 27.1.2.1.2,
7.4.6, and 7.4.9--12. This is a specification model, not an engine.
Only distinct already-acquired iterator records and the fixed token alphabet
are represented. Acquisition, options, padding, zipKeyed and arbitrary hooks
are outside this model. completed records a normal terminal observation;
it does not describe the generator's internal closed state after an exception.
"""
import argparse
import collections
import json
import sys
from pathlib import Path


def evaluate(case):
    n = case['n']
    prefix = case.get('prefix', 0)
    tokens = case['tokens']
    closes = case.get('closes', case.get('closing'))
    mode = case['mode']
    action = case.get('consumer_return')
    if action is None and case.get('family') == 'return':
        action = {'before': 'before-first', 'after_one': 'after-one-row'}[case['when']]
    if (not isinstance(n, int) or n < 0 or prefix not in (0, 1)
            or len(tokens) != n or len(closes) != n
            or any(t not in ('D', 'V', 'N', 'G', 'X', 'P') for t in tokens)
            or any(c not in ('R', 'E', 'P') for c in closes)
            or mode not in ('shortest', 'strict')
            or action not in (None, 'before-first', 'after-one-row')
            or (n == 0 and (prefix != 0 or action is not None))):
        raise ValueError('Case is outside the oracle domain')
    if action is not None and (prefix != 1 or any(t != 'V' for t in tokens)):
        raise ValueError('Consumer-return fixtures require prefix=1 and all V tokens')
    trace, rows = [], []
    calls = [0] * n
    opened = list(range(n))

    def finish(error):
        return {'rows': rows, 'trace': trace, 'error': error,
                'completed': error is None}

    def close_all(error):
        # IteratorCloseAll folds IteratorClose in reverse list order. An
        # existing throw wins, while every remaining close is still attempted.
        for i in reversed(opened):
            trace.extend([['get-return', i], ['return', i]])
            close_error = ('close:' + str(i) if closes[i] == 'E'
                           else 'TypeError' if closes[i] == 'P' else None)
            if error is None and close_error is not None:
                error = close_error
        return error

    def step(i, read_value):
        # IteratorNext rejects primitive results before IteratorComplete.
        index = calls[i]
        calls[i] += 1
        token = 'V' if index < prefix else tokens[i] if index == prefix else 'D'
        trace.append(['next', i])
        if token == 'N':
            return False, None, 'next:' + str(i)
        if token == 'P':
            return False, None, 'TypeError'
        trace.append(['done', i])
        if token == 'G':
            return False, None, 'done:' + str(i)
        if token == 'D':
            return True, None, None
        # Strict validation after the first done uses IteratorStep, not
        # IteratorStepValue: a non-done result's value getter is not evaluated.
        if not read_value:
            return False, None, None
        trace.append(['value', i])
        if token == 'X':
            return False, None, 'value:' + str(i)
        return False, [i, index], None

    if n == 0:
        trace.append(['client-next', 0])
        return finish(None)

    if action == 'before-first':
        trace.append(['client-return'])
        return finish(close_all(None))

    round_index = 0
    while True:
        trace.append(['client-next', round_index])
        row = []
        for i in range(n):
            done, value, error = step(i, True)
            if error is not None:
                opened.remove(i)
                return finish(close_all(error))
            if not done:
                row.append(value)
                continue
            opened.remove(i)
            if mode == 'shortest':
                return finish(close_all(None))
            if i != 0:
                return finish(close_all('TypeError'))
            for k in range(1, n):
                exhausted, _, error = step(k, False)
                if error is not None:
                    opened.remove(k)
                    return finish(close_all(error))
                if exhausted:
                    opened.remove(k)
                else:
                    return finish(close_all('TypeError'))
            return finish(None)
        rows.append(row)
        round_index += 1
        if action == 'after-one-row':
            trace.append(['client-return'])
            return finish(close_all(None))


def self_test():
    def case(tokens, closes=None, mode='strict', prefix=0, action=None):
        return dict(n=len(tokens), prefix=prefix, tokens=list(tokens),
                    closes=list(closes or 'R' * len(tokens)), mode=mode,
                    consumer_return=action)
    tests = []
    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        tests.append(name)
    r = evaluate(case(''))
    check('zero-input-normal-terminal-observation', r == {
        'rows': [], 'trace': [['client-next', 0]], 'error': None, 'completed': True})
    r = evaluate(case('DX'))
    check('strict-probe-does-not-read-value', r == {
        'rows': [], 'trace': [['client-next', 0], ['next', 0], ['done', 0],
                             ['next', 1], ['done', 1], ['get-return', 1], ['return', 1]],
        'error': 'TypeError', 'completed': False})
    r = evaluate(case('VDN', 'EEE'))
    check('strict-later-done-stops-demand', r['error'] == 'TypeError'
          and ['next', 2] not in r['trace']
          and [e for e in r['trace'] if e[0] == 'return'] == [['return', 2], ['return', 0]])
    r = evaluate(case('NV', 'EE'))
    check('source-throw-retained-and-failing-source-not-closed', r['error'] == 'next:0'
          and r['trace'][-2:] == [['get-return', 1], ['return', 1]])
    r = evaluate(case('DVV', 'REE', 'shortest'))
    check('normal-stop-first-reverse-close-error', r['error'] == 'close:2'
          and [e for e in r['trace'] if e[0] == 'return'] == [['return', 2], ['return', 1]])
    r = evaluate(case('PD'))
    check('primitive-result-does-not-read-done', ['done', 0] not in r['trace'])
    r = evaluate(case('GV', 'RE'))
    check('done-getter-error-retained', r['error'] == 'done:0')
    r = evaluate(case('XV', 'RE'))
    check('value-getter-error-retained', r['error'] == 'value:0')
    r = evaluate(case('DD', 'EE'))
    check('all-done-never-close', r['error'] is None and r['completed']
          and not any(e[0] == 'return' for e in r['trace']))
    r = evaluate(case('VV', 'RR', prefix=1))
    check('prefix-and-terminal-value-rows', r['rows'] == [[[0, 0], [1, 0]], [[0, 1], [1, 1]]]
          and r['completed'])
    r = evaluate(case('VV', 'RR', prefix=1, action='before-first'))
    check('return-before-first-has-no-demand', r['trace'] == [
        ['client-return'], ['get-return', 1], ['return', 1], ['get-return', 0], ['return', 0]])
    r = evaluate(case('VV', 'PE', prefix=1, action='after-one-row'))
    check('return-after-row-reverse-close-and-first-error', r['rows'] == [[[0, 0], [1, 0]]]
          and r['error'] == 'close:1' and r['completed'] is False
          and [e for e in r['trace'] if e[0] == 'return'] == [['return', 1], ['return', 0]])
    return {'status': 'PASS', 'checks': tests, 'count': len(tests)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default='-')
    parser.add_argument('--output', default='-')
    parser.add_argument('--summary')
    parser.add_argument('--check-actual', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), sort_keys=True))
        return
    source = sys.stdin if args.input == '-' else open(args.input, encoding='utf-8')
    sink = sys.stdout if args.output == '-' else open(args.output, 'x', encoding='utf-8')
    counts = collections.Counter()
    mismatches = []
    try:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            entry = json.loads(line)
            case = entry.get('case', entry)
            expected = evaluate(case)
            record = {'case': case, 'expected': expected}
            counts['cases'] += 1
            counts['family:' + case.get('family', 'protocol')] += 1
            counts['error:' + str(expected['error'])] += 1
            counts['rows'] += len(expected['rows'])
            counts['trace_events'] += len(expected['trace'])
            if args.check_actual:
                if 'actual' not in entry:
                    raise ValueError('Missing actual field at input line ' + str(line_number))
                match = entry['actual'] == expected
                record['match'] = match
                counts['actual_checked'] += 1
                counts['mismatches'] += not match
                if not match:
                    mismatches.append({'line': line_number, 'id': case.get('id')})
            encoded = json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n'
            sink.write(encoded)
    finally:
        if source is not sys.stdin:
            source.close()
        if sink is not sys.stdout:
            sink.close()
    summary = {'status': 'FAIL' if mismatches else 'PASS', 'counts': dict(counts),
               'mismatches': mismatches}
    encoded = json.dumps(summary, sort_keys=True) + '\n'
    if args.summary:
        with open(args.summary, 'x', encoding='utf-8') as stream:
            stream.write(encoded)
    sys.stderr.write(encoded)
    if mismatches:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
