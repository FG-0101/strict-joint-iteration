"""Reconcile all identities, coverage, full protocol traces and source results."""
from pathlib import Path
import argparse,collections,gzip,itertools,json
from spec_oracle import evaluate
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def read(d):
 with gzip.open(d/'rows.jsonl.gz','rt') as f:return [json.loads(x) for x in f]
base314=read(a.root/'native314');base312=read(a.root/'native312');assert len(base314)==18724 and len(base312)==9362
k=lambda r:json.dumps(r['case'],sort_keys=True)
b312={k(r):r for r in base312};assert len(b312)==9362
for row in base314:
 if row['case']['kind']=='zip':assert row['actual']==b312[k(row)]['actual']
expected_native={json.dumps({'n':n,'scripts':list(vector),'mode':mode,'kind':kind},sort_keys=True) for n in range(5) for vector in itertools.product(list(itertools.product(range(4),['D','N'])),repeat=n) for mode in ['shortest','strict'] for kind in ['zip','map']}
assert len({k(x) for x in base314})==len(base314)==18724
assert {k(x) for x in base314}==expected_native
assert {k(x) for x in base312}=={key for key in expected_native if json.loads(key)['kind']=='zip'}
bycase={}
for row in base314:
 c=row['case'];key=(json.dumps(c['scripts']),c['mode']);bycase.setdefault(key,{})[c['kind']]=row['actual']
for (scripts,mode),r in bycase.items():
 if scripts!='[]':assert r['zip']==r['map']
# The finite protocol universe is generated independently as a set of tuple descriptors.
expected=set()
for n in [2,3]:
 for prefix in [0,1]:
  for tokens in itertools.product('DVNGXP',repeat=n):
   for closes in itertools.product('REP',repeat=n):
    for mode in ['shortest','strict']:expected.add(('protocol',n,prefix,tokens,closes,mode,None))
for n in range(1,5):
 for closes in itertools.product('REP',repeat=n):
  for mode in ['shortest','strict']:
   for act in ['before-first','after-one-row']:expected.add(('return',n,1,('V',)*n,closes,mode,act))
expected.add(('zero',0,0,(),(),'strict',None));assert len(expected)==25105
report={'native314_cases':len(base314),'native312_cases':len(base312),'source_vectors_each':4681,'cross_version_zip_comparisons':9362,'cross_version_zip_disagreements':0,'zip_map_nonzero_arity_comparisons':9360,'zip_map_nonzero_disagreements':0,'protocol_cases_each':25105,'variants':{}}
first=[]
for variant in ['reference','repaired','eager']:
 rows=read(a.root/variant);assert len(rows)==25105;seen=set();ids=set();counts=collections.Counter();groups={};same_error_diff_trace=0
 with gzip.open(a.output/(variant+'_differences.jsonl.gz'),'wt') as out:
  for row in rows:
   c=row['case'];key=(c['family'],c['n'],c['prefix'],tuple(c['tokens']),tuple(c['closes']),c['mode'],c.get('consumer_return'));assert key not in seen;seen.add(key);assert c['id'] not in ids;ids.add(c['id']);want=evaluate(c);got=row['actual'];fields=[x for x in ['rows','trace','error','completed'] if want[x]!=got[x]];counts['cases']+=1
   group=groups.setdefault(c['family']+'|'+c['mode'],collections.Counter());group['cases']+=1;group['normal_done_expected']+=want['completed'];group['TypeError_expected']+=want['error']=='TypeError'
   if fields:
    counts['different_cases']+=1
    for x in fields:counts['different_'+x]+=1
    group['different_cases']+=1
    if got['error']==want['error'] and got['trace']!=want['trace']:same_error_diff_trace+=1
    if variant=='reference':assert 'P' in c['tokens'] or 'P' in c['closes'],c
    if variant=='eager':assert c['mode']=='strict' and c['family']=='protocol'
    rec={'case':c,'different_fields':fields,'actual':got,'expected':want};out.write(json.dumps(rec,sort_keys=True,separators=(',',':'))+'\n')
    if len(first)<9:first.append({'variant':variant,**rec})
   else:counts['equal_cases']+=1
 assert seen==expected and ids==set(range(25105))
 if variant=='repaired':assert counts['different_cases']==0
 report['variants'][variant]={'counts':dict(counts),'groups':{k:dict(v) for k,v in groups.items()},'same_error_different_trace':same_error_diff_trace,'duplicate_ids':0,'coverage':'complete product'}
# A common-core quotient erases inert getter/close events and normalizes only length-error classes.
native_index={k(row):row['actual'] for row in base314 if row['case']['kind']=='zip'}
projected=0
for row in read(a.root/'reference'):
 c=row['case']
 if c['family']!='protocol' or any(x not in 'DVN' for x in c['tokens']) or any(x!='R' for x in c['closes']):continue
 scripts=[[c['prefix']+(t=='V'),'N' if t=='N' else 'D'] for t in c['tokens']]
 pc={'n':c['n'],'scripts':scripts,'mode':c['mode'],'kind':'zip'};py=native_index[json.dumps(pc,sort_keys=True)];js=row['actual']
 assert py['rows']==js['rows'] and py['completed']==js['completed']
 assert py['error']==('Mismatch' if js['error']=='TypeError' else js['error'])
 keep=lambda trace:[e for e in trace if e[0] in ['client-next','next']]
 assert keep(py['trace'])==keep(js['trace']);projected+=1
assert projected==144
report['common_core_projected_cases']=projected;report['common_core_projected_disagreements']=0

# Complete product checks retain the reference differences.
report['status']='PASS'
(a.output/'summary.json').write_text(json.dumps(report,indent=2)+'\n');(a.output/'first_differences.json').write_text(json.dumps(first,indent=2)+'\n');print(json.dumps(report))
